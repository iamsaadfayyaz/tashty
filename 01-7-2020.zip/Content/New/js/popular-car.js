// var $e = $(e.relatedTarget);
//     var idx = $e.index();
//     var itemsPerSlide = 0;
//     var totalItems = $('.carousel-item').length;
    
//     if (idx >= totalItems-(itemsPerSlide-1)) {
//         var it = itemsPerSlide - (totalItems - idx);
      
//     }
         
    